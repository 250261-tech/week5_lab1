#include <iostream>
using namespace std;
int main() {
    int sum;
    for(int i=0;i<10;i++) {
        cout<<i<<endl;
        sum+=i;
    }
    cout<<sum<<endl;
    return 0;
}
