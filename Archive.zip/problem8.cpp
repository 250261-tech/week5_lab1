#include <iostream>
using namespace std;
int main() {
    string n;
    cin>>n;
    int c=strlen(n.c_str());
    for (int i=1;i<=c; i++) {

    }
}