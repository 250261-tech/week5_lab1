#include <iostream>
using namespace std;

int main() {
    int n;
    int credit;
    int total;
    cin>>n;
    for (int i=1;i<=n;i++) {
        cin>>credit>>total;


    }
}